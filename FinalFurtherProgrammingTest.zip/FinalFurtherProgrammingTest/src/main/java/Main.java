import Database.DatabaseConnector;

import java.sql.SQLException;

public class Main {
    public static void main (String[] args) throws SQLException {
        DatabaseConnector db = new DatabaseConnector();
        db.connect();
        if (db.connection != null) {
            System.out.println("Connected to the database");
        } else {
            System.out.println("Failed to connect to the database");
        }
    }
}