package Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnector {
    private static final String DB_URL = "jdbc:postgresql://aws-0-ap-southeast-1.pooler.supabase.com:6543/postgres?user=postgres.muxtahmskhxnuqaesfji&password=Luonggiabao1234";
    public static Connection connection = null;

    public Connection connect() throws SQLException {
        connection = DriverManager.getConnection(DB_URL);
        return connection;
    }
}